import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { FaBookOpen } from "react-icons/fa";
import { FaUserCircle } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";

function Header() {
  const { isAuthenticated, user } = useAuth();
  const { cartItems } = useCart();

  return (
    <header className="header">
      <div className="header-top">
        <h2 className="logo">
          <FaBookOpen /> Relatos de Papel{" "}
        </h2>
        <nav className="nav">
          <Link to="/">Inicio</Link>
          <Link to="/home">Catalogo</Link>

          {isAuthenticated ? (
            <>
              <Link to="/profile">Perfil</Link>
              <Link to="/checkout" className="cart-icon-container">
                <FaShoppingCart />

                {cartItems.length > 0 && (
                  <span className="cart-badge">{cartItems.length}</span>
                )}
              </Link>
              <span>Hola, {user.name}</span>
            </>
          ) : (
            <Link to="/login" className="menu-login-button">
              <FaUserCircle />
              {/* <span>Login</span> */}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}

export default Header;
